
# OTP integration

## Backend
- New model: `models/OTP.js` with TTL expiry.
- New routes: `routes/otpRoutes.js`
  - `POST /api/otp/send` body: `{ email, purpose: 'signup'|'login' }`
  - `POST /api/otp/verify` body: `{ email, code, purpose, fullname?, password? }`
- `server.js`: mounts `app.use('/api/otp', otpRoutes)`.
- `package.json`: adds `nodemailer`.

### Env
Add to `.env`:
```
EMAIL_USER=youraddress@gmail.com
EMAIL_PASS=your_app_password
EMAIL_SERVICE=gmail
OTP_TTL_MINUTES=5
```
If email creds are missing, server logs the OTP in console.

## Frontend
- New page: `frontend/otp.html`
- Script: `frontend/js/otp.js`

Set API base if deployed:
```js
localStorage.setItem('API_BASE', 'https://your-backend.onrender.com/api');
```

Flow:
1. Choose purpose (login/signup).
2. Enter email. Click "Send OTP".
3. Enter received OTP.
4. For signup also fill fullname and password on verify.
5. On success you get JWT in `localStorage.token`.

Generated: 2025-08-25T04:26:35.926599Z
